/**
 * I Forgot The Words, Not The Feeling.
 * Modular Interactive Story Engine for Jagriti (My Jagguu 💗)
 */

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    window.lucide.createIcons();
  }

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ========================================================================
     1. AUDIO CONTROLLER (Smooth Fade-in & Autoplay Fallback)
  ======================================================================== */
  class AudioController {
    constructor() {
      this.audio = document.getElementById('bg-music');
      this.btn = document.getElementById('music-toggle');
      this.label = document.getElementById('music-label');
      this.isPlaying = false;
      this.hasUserInteracted = false;
      this.fadeInterval = null;

      this.btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggle();
      });

      // Attempt graceful autoplay on first interaction anywhere
      const unlockAudio = () => {
        if (!this.hasUserInteracted) {
          this.hasUserInteracted = true;
          if (!this.isPlaying) {
            this.playWithFade(0.45);
          }
        }
        window.removeEventListener('pointerdown', unlockAudio);
      };
      window.addEventListener('pointerdown', unlockAudio, { once: true });
    }

    playWithFade(targetVolume = 0.45) {
      if (!this.audio) return;
      this.audio.volume = 0;
      const playPromise = this.audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            this.isPlaying = true;
            this.btn.classList.add('playing');
            this.label.textContent = 'Pause Music';
            clearInterval(this.fadeInterval);
            this.fadeInterval = setInterval(() => {
              if (this.audio.volume < targetVolume - 0.02) {
                this.audio.volume = Math.min(targetVolume, this.audio.volume + 0.03);
              } else {
                this.audio.volume = targetVolume;
                clearInterval(this.fadeInterval);
              }
            }, 80);
          })
          .catch(() => {
            // Browser blocked autoplay or music file not yet added by user
            this.isPlaying = false;
          });
      }
    }

    pause() {
      if (!this.audio) return;
      clearInterval(this.fadeInterval);
      this.audio.pause();
      this.isPlaying = false;
      this.btn.classList.remove('playing');
      this.label.textContent = 'Play Music';
    }

    toggle() {
      this.hasUserInteracted = true;
      if (this.isPlaying) {
        this.pause();
      } else {
        this.playWithFade(0.45);
      }
    }
  }

  /* ========================================================================
     2. PERSISTENT AMBIENT FLOATING HEARTS & SPARKLES CANVAS
  ======================================================================== */
  class AmbientParticles {
    constructor(canvasId) {
      this.canvas = document.getElementById(canvasId);
      this.ctx = this.canvas.getContext('2d');
      this.particles = [];
      this.rafId = null;
      this.resize();
      window.addEventListener('resize', () => this.resize());
      this.initParticles();
      if (!prefersReducedMotion) {
        this.loop();
      }
    }

    resize() {
      this.width = this.canvas.width = window.innerWidth;
      this.height = this.canvas.height = window.innerHeight;
    }

    initParticles() {
      const count = window.innerWidth < 600 ? 24 : 42;
      this.particles = Array.from({ length: count }, () => this.createParticle(true));
    }

    createParticle(randomY = false) {
      const isHeart = Math.random() > 0.35;
      return {
        x: Math.random() * this.width,
        y: randomY ? Math.random() * this.height : this.height + 20,
        size: isHeart ? 7 + Math.random() * 8 : 2 + Math.random() * 3,
        speedY: 0.35 + Math.random() * 0.65,
        speedX: (Math.random() - 0.5) * 0.4,
        opacity: 0.25 + Math.random() * 0.45,
        isHeart,
        wobble: Math.random() * Math.PI * 2,
        color: Math.random() > 0.5 ? '#f48fb1' : '#e8a5c0',
      };
    }

    drawHeart(x, y, size, color, opacity) {
      const ctx = this.ctx;
      ctx.save();
      ctx.translate(x, y);
      ctx.globalAlpha = opacity;
      ctx.fillStyle = color;
      ctx.beginPath();
      const topCurveHeight = size * 0.3;
      ctx.moveTo(0, topCurveHeight);
      ctx.bezierCurveTo(0, 0, -size / 2, 0, -size / 2, topCurveHeight);
      ctx.bezierCurveTo(-size / 2, (size + topCurveHeight) / 2, 0, (size + topCurveHeight) / 1.3, 0, size);
      ctx.bezierCurveTo(0, (size + topCurveHeight) / 1.3, size / 2, (size + topCurveHeight) / 2, size / 2, topCurveHeight);
      ctx.bezierCurveTo(size / 2, 0, 0, 0, 0, topCurveHeight);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    loop() {
      this.ctx.clearRect(0, 0, this.width, this.height);
      for (let i = 0; i < this.particles.length; i++) {
        const p = this.particles[i];
        p.y -= p.speedY;
        p.wobble += 0.02;
        p.x += p.speedX + Math.sin(p.wobble) * 0.25;

        if (p.y < -25) {
          this.particles[i] = this.createParticle(false);
          continue;
        }

        if (p.isHeart) {
          this.drawHeart(p.x, p.y, p.size, p.color, p.opacity);
        } else {
          this.ctx.save();
          this.ctx.globalAlpha = p.opacity * (0.6 + 0.4 * Math.sin(p.wobble * 2));
          this.ctx.fillStyle = '#ffffff';
          this.ctx.beginPath();
          this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          this.ctx.fill();
          this.ctx.restore();
        }
      }
      this.rafId = requestAnimationFrame(() => this.loop());
    }
  }

  /* ========================================================================
     3. SCENE MANAGER (Lifecycle Init & Cleanup)
  ======================================================================== */
  class SceneManager {
    constructor(scenes) {
      this.scenes = scenes;
      this.currentId = null;
    }

    goTo(nextId) {
      if (this.currentId === nextId) return;

      const prevScene = this.currentId ? this.scenes[this.currentId] : null;
      const nextScene = this.scenes[nextId];
      if (!nextScene) return;

      const finalizeTransition = () => {
        if (prevScene) {
          prevScene.el.classList.remove('active');
          if (typeof prevScene.cleanup === 'function') {
            prevScene.cleanup();
          }
        }
        nextScene.el.classList.add('active');
        this.currentId = nextId;
        if (typeof nextScene.init === 'function') {
          nextScene.init();
        }
        gsap.fromTo(
          nextScene.el,
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.65, ease: 'power3.out' }
        );
      };

      if (prevScene) {
        gsap.to(prevScene.el, {
          opacity: 0,
          y: -14,
          duration: 0.45,
          ease: 'power2.in',
          onComplete: finalizeTransition,
        });
      } else {
        finalizeTransition();
      }
    }
  }

  /* ========================================================================
     4. SCENE DEFINITIONS
  ======================================================================== */

  // --- SCENE 1: CINEMATIC INTRODUCTION ---
  const scene1 = {
    el: document.getElementById('scene-1'),
    init() {
      const btn = document.getElementById('btn-scene-1');
      const flap = document.getElementById('intro-flap');
      const seal = document.getElementById('intro-seal');
      const peek = document.querySelector('.env-letter-peek');

      // Reset envelope state on replay
      gsap.set(flap, { rotateX: 0, zIndex: 4 });
      gsap.set(seal, { scale: 1, opacity: 1 });
      gsap.set(peek, { y: 0 });

      btn.disabled = false;
      btn.onclick = () => {
        btn.disabled = true;
        const tl = gsap.timeline({
          onComplete: () => manager.goTo('scene2'),
        });

        tl.to(seal, { scale: 0, opacity: 0, duration: 0.3, ease: 'back.in(2)' })
          .to(flap, { rotateX: 180, duration: 0.55, ease: 'power2.inOut' }, '-=0.1')
          .set(flap, { zIndex: 1 })
          .to(peek, { y: -42, duration: 0.5, ease: 'power3.out' }, '-=0.15');
      };
    },
    cleanup() {},
  };

  // --- SCENE 2: LOVE SYSTEM.EXE ---
  const scene2 = {
    el: document.getElementById('scene-2'),
    timers: [],
    init() {
      const output = document.getElementById('terminal-output');
      const cursor = document.getElementById('terminal-cursor');
      const repairBtn = document.getElementById('btn-repair');
      const repairPanel = document.getElementById('repair-panel');
      const progressFill = document.getElementById('repair-progress-fill');
      const percentLabel = document.getElementById('repair-percent');
      const statusText = document.getElementById('repair-status-text');
      const terminalWindow = document.getElementById('terminal-window');

      output.innerHTML = '';
      cursor.style.display = 'inline-block';
      repairBtn.classList.add('hidden');
      repairBtn.disabled = false;
      repairPanel.classList.add('hidden');
      progressFill.style.width = '0%';
      percentLabel.textContent = '0%';

      const lines = [
        { text: 'LOVE SYSTEM v2.0', cls: 'header-line' },
        { text: '⚠️ CRITICAL ERROR DETECTED!', cls: 'alert-line' },
        { text: 'Three magical words were not delivered yesterday!', cls: '' },
        { text: 'ERROR CODE: ILU_001', cls: 'code-line' },
        { text: 'Cause: Someone forgot something VERY important. 💀', cls: '' },
        { text: 'Status: Immediate romantic repair required! ❤️', cls: '' },
      ];

      let lineIdx = 0;
      let charIdx = 0;
      let currentLineEl = null;

      const typeNext = () => {
        if (lineIdx >= lines.length) {
          repairBtn.classList.remove('hidden');
          gsap.fromTo(repairBtn, { scale: 0.85, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(1.7)' });
          return;
        }

        const lineObj = lines[lineIdx];
        if (charIdx === 0) {
          currentLineEl = document.createElement('div');
          currentLineEl.className = `t-line ${lineObj.cls}`;
          output.appendChild(currentLineEl);
        }

        const chars = Array.from(lineObj.text);
        if (charIdx < chars.length) {
          currentLineEl.textContent += chars[charIdx];
          charIdx++;
          const delay = prefersReducedMotion ? 2 : 24;
          this.timers.push(setTimeout(typeNext, delay));
        } else {
          lineIdx++;
          charIdx = 0;
          this.timers.push(setTimeout(typeNext, prefersReducedMotion ? 10 : 220));
        }
      };

      typeNext();

      repairBtn.onclick = () => {
        repairBtn.disabled = true;
        terminalWindow.classList.add('terminal-glitch');
        repairPanel.classList.remove('hidden');
        cursor.style.display = 'none';

        const progressObj = { val: 0 };
        gsap.to(progressObj, {
          val: 100,
          duration: 1.9,
          ease: 'power2.inOut',
          onUpdate: () => {
            const pct = Math.round(progressObj.val);
            progressFill.style.width = `${pct}%`;
            percentLabel.textContent = `${pct}%`;
            if (pct > 35 && pct < 75) {
              statusText.textContent = 'Injecting extra cuddles & apologies...';
            } else if (pct >= 75 && pct < 100) {
              statusText.textContent = 'Preparing handwritten confession...';
            } else if (pct === 100) {
              statusText.textContent = '✅ Romantic Repair Complete! Opening letter...';
            }
          },
          onComplete: () => {
            terminalWindow.classList.remove('terminal-glitch');
            this.timers.push(setTimeout(() => manager.goTo('scene3'), 650));
          },
        });
      };
    },
    cleanup() {
      this.timers.forEach((id) => clearTimeout(id));
      this.timers = [];
    },
  };

  // --- SCENE 3: PERSONAL APOLOGY LETTER ---
  const scene3 = {
    el: document.getElementById('scene-3'),
    timer: null,
    init() {
      const textEl = document.getElementById('handwritten-text');
      const scrollArea = document.getElementById('letter-scroll-area');
      const openHeartBtn = document.getElementById('btn-open-heart');
      const paperSheet = document.getElementById('paper-sheet');

      // EXACT preserved personal apology message
      const exactMessage = `Sorryy Jagguu for being a littile stupid yesterday😇, Kal Mene I love you nhi bola apko Sorry bandariyaa yk mere liye tooh wo 3 words bhi kafi nhi hai ye btane ke liye ki m aapse kitnaaa jyadaa pyar krta hu, agar mujhe world ke sare languages ya sare words pta ho fir bhi mere pass words kam pad jayenge ye btane ke liye ki m Kitna Jayada pyar krta hu meriii Tingii se😚.
Again sorryyy Bbyyyy, ❤️
Please Forgive me Malkin😭, Aab aaisa kabhi nhi hogaa muwaahhhh 💋`;

      textEl.textContent = '';
      openHeartBtn.classList.add('hidden');

      gsap.fromTo(
        paperSheet,
        { y: 45, opacity: 0, rotateX: 8 },
        { y: 0, opacity: 1, rotateX: 0, duration: 0.75, ease: 'power3.out' }
      );

      const chars = Array.from(exactMessage);
      let idx = 0;

      const writeChar = () => {
        if (idx < chars.length) {
          textEl.textContent += chars[idx];
          idx++;
          scrollArea.scrollTop = scrollArea.scrollHeight;
          const speed = prefersReducedMotion ? 1 : 22;
          this.timer = setTimeout(writeChar, speed);
        } else {
          openHeartBtn.classList.remove('hidden');
          gsap.fromTo(
            openHeartBtn,
            { y: 14, opacity: 0, scale: 0.9 },
            { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: 'back.out(1.7)' }
          );
        }
      };

      this.timer = setTimeout(writeChar, 400);

      openHeartBtn.onclick = () => {
        manager.goTo('scene4');
      };
    },
    cleanup() {
      if (this.timer) clearTimeout(this.timer);
    },
  };

  // --- SCENE 4 & 5: GIANT 3D HEART & LOVE CONFESSION ---
  const scene4 = {
    el: document.getElementById('scene-4'),
    rafId: null,
    renderer: null,
    timers: [],
    onResize: null,
    init() {
      const container = document.getElementById('three-heart-container');
      const statusLabel = document.getElementById('heart-fill-label');
      const confessionStage = document.getElementById('confession-stage');
      const msg1 = document.getElementById('msg-1');
      const msg2 = document.getElementById('msg-2');
      const msg3 = document.getElementById('msg-3');
      const nextBtn = document.getElementById('btn-to-pigguu');

      container.innerHTML = '';
      statusLabel.textContent = 'Filling my heart with love for you...';
      gsap.set(confessionStage, { opacity: 0, y: 18 });
      gsap.set([msg1, msg2, msg3], { opacity: 0, y: 12 });
      nextBtn.classList.add('hidden');

      // Three.js Setup
      const width = container.clientWidth || window.innerWidth;
      const height = container.clientHeight || window.innerHeight;

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
      camera.position.set(0, 0.25, width < 600 ? 7.4 : 6.0);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      container.appendChild(renderer.domElement);
      this.renderer = renderer;

      // Lights
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.95);
      scene.add(ambientLight);

      const dirLight = new THREE.DirectionalLight(0xffd6e7, 1.2);
      dirLight.position.set(4, 6, 7);
      scene.add(dirLight);

      const rimLight = new THREE.PointLight(0xff4d88, 1.5, 15);
      rimLight.position.set(-3, -2, 4);
      scene.add(rimLight);

      // Shared Mini 3D Heart Geometry
      const heartShape = new THREE.Shape();
      heartShape.moveTo(0, 0.25);
      heartShape.bezierCurveTo(0, 0.25, -0.05, 0.45, -0.25, 0.45);
      heartShape.bezierCurveTo(-0.55, 0.45, -0.55, 0.1, -0.55, 0.1);
      heartShape.bezierCurveTo(-0.55, -0.15, -0.35, -0.4, 0, -0.6);
      heartShape.bezierCurveTo(0.35, -0.4, 0.55, -0.15, 0.55, 0.1);
      heartShape.bezierCurveTo(0.55, 0.1, 0.55, 0.45, 0.25, 0.45);
      heartShape.bezierCurveTo(0.1, 0.45, 0, 0.25, 0, 0.25);

      const extrudeSettings = {
        depth: 0.18,
        bevelEnabled: true,
        bevelSegments: 2,
        steps: 1,
        bevelSize: 0.06,
        bevelThickness: 0.06,
      };
      const miniHeartGeo = new THREE.ExtrudeGeometry(heartShape, extrudeSettings);
      miniHeartGeo.center();

      // Master Heart Container Group
      const heartGroup = new THREE.Group();
      heartGroup.position.y = 0.55;
      scene.add(heartGroup);

      // Translucent Outer Giant Heart Shell (Outline Guide)
      const shellGeo = new THREE.ExtrudeGeometry(heartShape, {
        depth: 0.45,
        bevelEnabled: true,
        bevelSegments: 4,
        steps: 1,
        bevelSize: 0.18,
        bevelThickness: 0.18,
      });
      shellGeo.center();
      shellGeo.scale(2.85, 2.85, 2.4);

      const shellMat = new THREE.MeshPhysicalMaterial({
        color: 0xffb3cc,
        transparent: true,
        opacity: 0.18,
        roughness: 0.2,
        metalness: 0.05,
        side: THREE.DoubleSide,
      });
      const shellMesh = new THREE.Mesh(shellGeo, shellMat);
      heartGroup.add(shellMesh);

      // Subtle glowing wireframe outline of the giant heart
      const wireGeo = new THREE.EdgesGeometry(shellGeo, 18);
      const wireMat = new THREE.LineBasicMaterial({
        color: 0xf06292,
        transparent: true,
        opacity: 0.42,
      });
      const wireMesh = new THREE.LineSegments(wireGeo, wireMat);
      heartGroup.add(wireMesh);

      // Generate exact interior points inside 3D heart volume
      // Implicit heart formula: (x^2 + 9/4 y^2 + z^2 - 1)^3 - x^2 z^3 - 9/80 y^2 z^3 <= 0
      const isInsideHeart = (x, y, z) => {
        const a = x * x + (9 / 4) * y * y + z * z - 1;
        return a * a * a - x * x * z * z * z - (9 / 80) * y * y * z * z * z <= 0;
      };

      const particleCount = window.innerWidth < 600 ? 320 : 450;
      const palette = [0xff4d88, 0xff75a0, 0xe83e75, 0xff9ebb, 0xd81b60, 0xffb3c6];
      const materials = palette.map(
        (hex) =>
          new THREE.MeshStandardMaterial({
            color: hex,
            roughness: 0.35,
            metalness: 0.1,
            emissive: hex,
            emissiveIntensity: 0.18,
          })
      );

      const heartsData = [];
      let attempts = 0;

      while (heartsData.length < particleCount && attempts < 30000) {
        attempts++;
        const rx = (Math.random() * 2 - 1) * 1.15;
        const ry = (Math.random() * 2 - 1) * 1.15;
        const rz = (Math.random() * 2 - 1) * 1.15;

        // Map (rx, rz=vertical, ry=depth) to Three.js (X, Y=vertical, Z=depth)
        if (isInsideHeart(rx, ry * 0.85, rz)) {
          const target = new THREE.Vector3(rx * 1.48, (rz - 0.12) * 1.45, ry * 0.95);

          // Start scattered around outer space
          const angle = Math.random() * Math.PI * 2;
          const radius = 3.5 + Math.random() * 3.8;
          const start = new THREE.Vector3(
            Math.cos(angle) * radius,
            (Math.random() - 0.5) * 6.5,
            Math.sin(angle) * radius
          );

          const mesh = new THREE.Mesh(miniHeartGeo, materials[heartsData.length % materials.length]);
          const scale = 0.085 + Math.random() * 0.055;
          mesh.scale.set(scale, scale, scale);
          mesh.position.copy(start);
          mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);

          heartGroup.add(mesh);

          heartsData.push({
            mesh,
            start,
            target,
            delay: (heartsData.length / particleCount) * 0.62,
            rotSpeed: (Math.random() - 0.5) * 0.04,
          });
        }
      }

      // Animation State
      const clock = new THREE.Clock();
      const fillDuration = prefersReducedMotion ? 0.5 : 4.2;
      let isFilled = false;
      let confessionStarted = false;

      const triggerConfessionSequence = () => {
        if (confessionStarted) return;
        confessionStarted = true;
        statusLabel.textContent = '100% Full of Love for Jagriti 💗';

        const tl = gsap.timeline();
        tl.to(confessionStage, { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' })
          .to(msg1, { opacity: 1, y: 0, duration: 0.7, ease: 'power3.out' })
          .to(msg2, { opacity: 1, y: 0, duration: 0.7, ease: 'power3.out' }, '+=0.55')
          .to(msg3, { opacity: 1, y: 0, duration: 0.7, ease: 'power3.out' }, '+=0.65')
          .add(() => {
            nextBtn.classList.remove('hidden');
            gsap.fromTo(
              nextBtn,
              { scale: 0.85, opacity: 0 },
              { scale: 1, opacity: 1, duration: 0.45, ease: 'back.out(1.7)' }
            );
          }, '+=0.4');
      };

      const animate = () => {
        this.rafId = requestAnimationFrame(animate);
        const elapsed = clock.getElapsedTime();

        // Gentle orbital sway of giant heart
        heartGroup.rotation.y = Math.sin(elapsed * 0.65) * 0.32;

        let allDone = true;
        for (let i = 0; i < heartsData.length; i++) {
          const item = heartsData[i];
          const localTime = elapsed - item.delay * fillDuration;
          const rawT = Math.max(0, Math.min(1, localTime / (fillDuration * 0.45)));

          if (rawT < 1) allDone = false;

          // Smooth cubic ease-out
          const easeT = 1 - Math.pow(1 - rawT, 3);
          item.mesh.position.lerpVectors(item.start, item.target, easeT);

          if (rawT < 1) {
            item.mesh.rotation.y += item.rotSpeed;
          } else {
            // Align neatly forward once inside heart
            item.mesh.rotation.x *= 0.92;
            item.mesh.rotation.y *= 0.92;
          }
        }

        if (allDone && !isFilled) {
          isFilled = true;
          triggerConfessionSequence();
        }

        // Rhythmic heartbeat pulse once filled
        if (isFilled) {
          const beat = 1 + Math.pow(Math.sin(elapsed * 3.2), 4) * 0.065;
          heartGroup.scale.set(beat, beat, beat);
        }

        renderer.render(scene, camera);
      };

      animate();

      this.onResize = () => {
        if (!this.renderer) return;
        const w = container.clientWidth || window.innerWidth;
        const h = container.clientHeight || window.innerHeight;
        camera.aspect = w / h;
        camera.position.z = w < 600 ? 7.4 : 6.0;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };
      window.addEventListener('resize', this.onResize);

      nextBtn.onclick = () => {
        manager.goTo('scene6');
      };
    },
    cleanup() {
      if (this.rafId) cancelAnimationFrame(this.rafId);
      if (this.onResize) window.removeEventListener('resize', this.onResize);
      if (this.renderer) {
        this.renderer.dispose();
        this.renderer = null;
      }
      this.timers.forEach((t) => clearTimeout(t));
      this.timers = [];
    },
  };

  // --- SCENE 6: THE PIGGUU KISS EXPERIENCE ---
  const scene6 = {
    el: document.getElementById('scene-6'),
    idleTween: null,
    init() {
      const promptBox = document.getElementById('pigguu-prompt-box');
      const celebBox = document.getElementById('pigguu-celebration-box');
      const sendKissBtn = document.getElementById('btn-send-kiss');
      const moreKissesBtn = document.getElementById('btn-more-kisses');
      const replayBtn = document.getElementById('btn-replay-story');
      const burstLayer = document.getElementById('kiss-burst-layer');

      const pigWhole = document.getElementById('pig-whole');
      const eyesNormal = document.getElementById('pig-eyes-normal');
      const eyesHappy = document.getElementById('pig-eyes-happy');
      const mouthPout = document.getElementById('pig-mouth-pout');
      const mouthHappy = document.getElementById('pig-mouth-happy');
      const earLeft = document.getElementById('pig-ear-left');
      const earRight = document.getElementById('pig-ear-right');

      // Reset State
      promptBox.classList.remove('hidden');
      celebBox.classList.add('hidden');
      burstLayer.innerHTML = '';
      gsap.set(eyesNormal, { opacity: 1 });
      gsap.set(eyesHappy, { opacity: 0 });
      gsap.set(mouthPout, { opacity: 1 });
      gsap.set(mouthHappy, { opacity: 0 });
      gsap.set(pigWhole, { y: 0, scale: 1, rotation: 0 });

      // Cute Idle Breathing & Ear Wiggle
      if (!prefersReducedMotion) {
        this.idleTween = gsap.timeline({ repeat: -1, yoyo: true });
        this.idleTween
          .to(pigWhole, { y: -6, duration: 1.4, ease: 'sine.inOut' }, 0)
          .to(earLeft, { rotation: -8, duration: 0.9, ease: 'sine.inOut' }, 0)
          .to(earRight, { rotation: 8, duration: 0.9, ease: 'sine.inOut' }, 0.2);
      }

      // Synthesized Cute Pop/Chime Sound (Works with zero external audio dependencies)
      const playCuteKissSound = () => {
        try {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;
          if (!AudioCtx) return;
          const ctx = new AudioCtx();
          const now = ctx.currentTime;

          const notes = [523.25, 659.25, 783.99, 1046.5];
          notes.forEach((freq, idx) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now + idx * 0.06);
            gain.gain.setValueAtTime(0.08, now + idx * 0.06);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.06 + 0.35);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now + idx * 0.06);
            osc.stop(now + idx * 0.06 + 0.36);
          });
        } catch (_) {
          // Safe fallback if audio context is restricted
        }
      };

      // Spawn Hundreds of Flying Kisses & Hearts
      const spawnKissShower = (count = 85) => {
        const symbols = ['💋', '💋', '💋', '❤️', '💗', '🐷', '💕'];
        const vw = window.innerWidth;
        const vh = window.innerHeight;

        for (let i = 0; i < count; i++) {
          const span = document.createElement('span');
          span.className = 'flying-kiss';
          span.textContent = symbols[i % symbols.length];

          const startX = Math.random() * vw;
          const startY = vh + 30 + Math.random() * 140;
          const endY = -80 - Math.random() * 120;
          const driftX = (Math.random() - 0.5) * 220;
          const scale = 0.75 + Math.random() * 1.1;

          span.style.left = `${startX}px`;
          span.style.top = `${startY}px`;
          span.style.fontSize = `${(1.35 * scale).toFixed(2)}rem`;

          burstLayer.appendChild(span);

          gsap.to(span, {
            y: endY - startY,
            x: driftX,
            rotation: (Math.random() - 0.5) * 90,
            opacity: 0,
            duration: 2.2 + Math.random() * 1.8,
            delay: Math.random() * 0.85,
            ease: 'power1.out',
            onComplete: () => span.remove(),
          });
        }
      };

      const celebrateKiss = () => {
        playCuteKissSound();
        spawnKissShower(window.innerWidth < 600 ? 75 : 115);

        // Switch Pigguu expression to ecstatic joy
        gsap.to(eyesNormal, { opacity: 0, duration: 0.2 });
        gsap.to(eyesHappy, { opacity: 1, duration: 0.2 });
        gsap.to(mouthPout, { opacity: 0, duration: 0.2 });
        gsap.to(mouthHappy, { opacity: 1, duration: 0.2 });

        // Joyful Pigguu Jump & Wiggle
        gsap.timeline()
          .to(pigWhole, { y: -26, scale: 1.12, rotation: -6, duration: 0.25, ease: 'power2.out' })
          .to(pigWhole, { y: 0, scale: 1, rotation: 6, duration: 0.25, ease: 'bounce.out' })
          .to(pigWhole, { rotation: 0, duration: 0.2 });

        if (!promptBox.classList.contains('hidden')) {
          promptBox.classList.add('hidden');
          celebBox.classList.remove('hidden');
          gsap.fromTo(
            celebBox,
            { scale: 0.88, opacity: 0, y: 16 },
            { scale: 1, opacity: 1, y: 0, duration: 0.55, ease: 'back.out(1.7)' }
          );
        }
      };

      sendKissBtn.onclick = celebrateKiss;
      moreKissesBtn.onclick = () => {
        playCuteKissSound();
        spawnKissShower(60);
        gsap.timeline()
          .to(pigWhole, { y: -20, scale: 1.08, duration: 0.2, ease: 'power2.out' })
          .to(pigWhole, { y: 0, scale: 1, duration: 0.25, ease: 'bounce.out' });
      };

      replayBtn.onclick = () => {
        manager.goTo('scene1');
      };
    },
    cleanup() {
      if (this.idleTween) {
        this.idleTween.kill();
        this.idleTween = null;
      }
      document.getElementById('kiss-burst-layer').innerHTML = '';
    },
  };

  /* ========================================================================
     5. BOOTSTRAP APPLICATION
  ======================================================================== */
  new AudioController();
  new AmbientParticles('ambient-canvas');

  const manager = new SceneManager({
    scene1,
    scene2,
    scene3,
    scene4,
    scene6,
  });

  manager.goTo('scene1');
});