# I Forgot The Words, Not The Feeling. 💗

An interactive romantic apology experience created for **Jagriti (My Jagguu)**.

## Folder Structure

```text
project/
├── index.html
├── style.css
├── script.js
├── assets/
│   ├── music/
│   │   └── background-music.mp3
│   ├── images/
│   ├── models/
│   └── sounds/
└── README.md